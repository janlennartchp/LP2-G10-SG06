#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

// ================== Ingrediente ==================
class Ingrediente {
public:
    string nombre;
    double cantidad;
    double minimo;
    double precioUnitario;

    Ingrediente(string n = "", double c = 0, double m = 0, double p = 0)
        : nombre(n), cantidad(c), minimo(m), precioUnitario(p) {}
};

// ================== Inventario ==================
class Inventario {
public:
    map<string, Ingrediente> stock;

    void agregarIngrediente(const Ingrediente& ing) {
        stock[ing.nombre] = ing;
    }

    void actualizarIngrediente(string nombre, double nuevaCantidad, double nuevoPrecio) {
        if (stock.count(nombre)) {
            stock[nombre].cantidad = nuevaCantidad;
            stock[nombre].precioUnitario = nuevoPrecio;
        }
    }

    void descontarIngrediente(string nombre, double cantidad) {
        if (stock.count(nombre)) {
            stock[nombre].cantidad -= cantidad;
        }
    }

    bool haySuficiente(string nombre, double cantidad) {
        return stock.count(nombre) && stock[nombre].cantidad >= cantidad;
    }

    void mostrarStock() const {
        cout << "\n== STOCK DE INGREDIENTES ==\n";
        for (const auto& par : stock) {
            cout << "- " << par.first << ": " << par.second.cantidad
                 << " (mínimo: " << par.second.minimo << ")\n";
        }
    }

    void productosPorReponer() const {
        cout << "\n== PRODUCTOS POR REPONER ==\n";
        for (const auto& par : stock) {
            if (par.second.cantidad <= par.second.minimo) {
                cout << "- " << par.first << ": " << par.second.cantidad
                     << " (mínimo: " << par.second.minimo << ")\n";
            }
        }
    }
};

// ================== Plato ==================
class Plato {
public:
    string nombre;
    double precio;
    map<string, double> receta;

    Plato(string n = "", double p = 0) : nombre(n), precio(p) {}

    void agregarIngrediente(string nombreIng, double cantidad) {
        receta[nombreIng] = cantidad;
    }

    void operator+=(const Ingrediente& ing) {
        receta[ing.nombre] += ing.cantidad;
    }

    bool puedePrepararse(Inventario& inv) const {
        for (auto& par : receta) {
            if (!inv.haySuficiente(par.first, par.second)) return false;
        }
        return true;
    }

    void descontarIngredientes(Inventario& inv) {
        for (auto& par : receta) {
            inv.descontarIngrediente(par.first, par.second);
        }
    }

    void mostrar() const {
        cout << "Plato: " << nombre << ", Precio: " << precio << "\nIngredientes:\n";
        for (auto& par : receta) {
            cout << " - " << par.first << ": " << par.second << endl;
        }
    }
};

// ================== Mozo ==================
class Mozo {
public:
    string nombre;
    string dni;
    string celular;

    Mozo(string n = "", string d = "", string c = "") : nombre(n), dni(d), celular(c) {}

    void actualizarDatos(string n, string d, string c) {
        nombre = n;
        dni = d;
        celular = c;
    }

    void mostrar() const {
        cout << "Mozo: " << nombre << ", DNI: " << dni << ", Celular: " << celular << endl;
    }
};

// ================== Pedido ==================
class Pedido {
protected:
    static int contador;
public:
    int id;
    vector<Plato> platos;
    double total;
    string tipo; // mesa o delivery
    string categoria; // entrada, fondo, bebida, postre
    string mozo;

    Pedido() : id(++contador), total(0.0) {}

    virtual ~Pedido() {}

    void agregarPlato(const Plato& p) {
        platos.push_back(p);
        total += p.precio;
    }

    virtual void mostrar() const {
        cout << "Pedido ID: " << id << ", Total: S/ " << total << "\n";
        for (auto& p : platos) {
            cout << " - " << p.nombre << " (S/ " << p.precio << ")\n";
        }
    }

    double obtenerTotal() const {
        return total;
    }
};
int Pedido::contador = 0;

// ================== PedidoMesa ==================
class PedidoMesa : public Pedido {
public:
    int numeroMesa;

    PedidoMesa(int num, string mozoNombre) : numeroMesa(num) {
        tipo = "mesa";
        mozo = mozoNombre;
    }

    void mostrar() const override {
        cout << "\n--- Pedido en Mesa #" << numeroMesa << " ---\n";
        Pedido::mostrar();
    }
};

// ================== PedidoDomicilio ==================
class PedidoDomicilio : public Pedido {
public:
    string direccion;

    PedidoDomicilio(string dir, string mozoNombre) : direccion(dir) {
        tipo = "delivery";
        mozo = mozoNombre;
    }

    void mostrar() const override {
        cout << "\n--- Pedido a Domicilio ---\nDirección: " << direccion << endl;
        Pedido::mostrar();
    }
};

// ================== Administrador ==================
class Administrador {
public:
    vector<Plato> platos;
    vector<Pedido*> pedidos;

    void agregarPlato(string nombre, double precio, map<string, double> ingredientes) {
        Plato p(nombre, precio);
        for (auto& par : ingredientes) {
            p.agregarIngrediente(par.first, par.second);
        }
        platos.push_back(p);
    }

    void listarPlatos() const {
        for (const auto& p : platos) {
            p.mostrar();
        }
    }

    void agregarPedido(Pedido* pedido) {
        pedidos.push_back(pedido);
    }

    void reporteVentasPorPlato() const {
        map<string, double> ventas;
        for (auto pedido : pedidos) {
            for (auto& p : pedido->platos) {
                ventas[p.nombre] += p.precio;
            }
        }
        cout << "\n== VENTAS POR PLATO ==\n";
        for (auto& par : ventas) {
            cout << "- " << par.first << ": S/ " << par.second << endl;
        }
    }

    void reporteVentasPorMozo() const {
        map<string, double> ventas;
        for (auto pedido : pedidos) {
            ventas[pedido->mozo] += pedido->total;
        }
        cout << "\n== VENTAS POR MOZO ==\n";
        for (auto& par : ventas) {
            cout << "- " << par.first << ": S/ " << par.second << endl;
        }
    }

    void reporteVentasPorTipo() const {
        double mesa = 0, delivery = 0;
        for (auto pedido : pedidos) {
            if (pedido->tipo == "mesa") mesa += pedido->total;
            else delivery += pedido->total;
        }
        cout << "\n== VENTAS POR TIPO ==\n";
        cout << "Mesa: S/ " << mesa << "\nDelivery: S/ " << delivery << endl;
    }

    void platosPreparables(Inventario& inv) const {
        cout << "\n== PLATOS QUE PUEDEN PREPARARSE ==\n";
        for (auto& p : platos) {
            if (p.puedePrepararse(inv)) {
                cout << "- " << p.nombre << endl;
            }
        }
    }
};

// ================== MAIN ==================
int main() {
    Inventario inv;
    Administrador admin;

    inv.agregarIngrediente(Ingrediente("Arroz", 1000, 200, 0.5));
    inv.agregarIngrediente(Ingrediente("Pollo", 500, 100, 1.2));
    inv.agregarIngrediente(Ingrediente("Papa", 300, 50, 0.3));

    // Crear y registrar plato
    map<string, double> recetaChaufa = {{"Arroz", 200}, {"Pollo", 150}};
    admin.agregarPlato("Arroz Chaufa", 15.0, recetaChaufa);

    // Crear pedido mesa
    PedidoMesa* pedido1 = new PedidoMesa(1, "Luis");
    pedido1->agregarPlato(admin.platos[0]);
    pedido1->platos[0].descontarIngredientes(inv);
    admin.agregarPedido(pedido1);

    // Crear pedido delivery
    PedidoDomicilio* pedido2 = new PedidoDomicilio("Av. Arequipa 123", "Luis");
    pedido2->agregarPlato(admin.platos[0]);
    pedido2->platos[0].descontarIngredientes(inv);
    admin.agregarPedido(pedido2);

    // Reportes
    inv.mostrarStock();
    inv.productosPorReponer();
    admin.reporteVentasPorPlato();
    admin.reporteVentasPorMozo();
    admin.reporteVentasPorTipo();
    admin.platosPreparables(inv);

    // Liberar memoria
    delete pedido1;
    delete pedido2;

    return 0;
}
